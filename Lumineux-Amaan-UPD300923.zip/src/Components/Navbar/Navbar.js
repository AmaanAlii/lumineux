import React from "react";
import "./Navbar.css";

import LogoPrimary from "../../Assets/Navbar/Lumineux-Logo-Primary.png";
import LogoSecondary from "../../Assets/Navbar/Lumineux-Logo-Secondary.png";

function Navbar({ transparent }) {
  return (
    <div
      className={`navbar-component ${
        transparent ? "transparent" : "notTransparent"
      }`}
    >
      <img src={LogoSecondary} alt="Logo" />
      <ul className="nav-menu-list">
        <li>Home</li>
        <li>About us</li>
        <li className="nav-logo-container">
          <img src={LogoPrimary} alt="Logo 2" />
        </li>
        <li>Properties</li>
        <li>Blog</li>
      </ul>
      <button className="button-primary">Contact us</button>
    </div>
  );
}

export default Navbar;
